﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LatvanyossagokApplication
{
    public partial class Form1 : Form
    {

        private List<varosokCl> listaV = new List<varosokCl>();
        private List<latvanyossagokCl> listaL = new List<latvanyossagokCl>();
        private MySqlConnection conn;

        public Form1()
        {
            InitializeComponent();

            conn = new MySqlConnection(@"Server=localhost;Database=latvanyossagokdb;Uid=root;Pwd=;CharSet=utf8;Port=;");
            conn.Open();

            CreateTables();
            VarosokListazasa();
            LatvanyossagokListazasa();

        }

        public void CreateTables()
        {
            var cmd = conn.CreateCommand();
            cmd.CommandText = File.ReadAllText("db.sql");
            cmd.ExecuteNonQuery();
        }

        public void VarosokListazasa()
        {
            varoslistaz.Items.Clear();
            var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT * FROM varosok ORDER BY nev";
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    int id = reader.GetInt32("id");
                    string nev = reader.GetString("nev");
                    int lakossag = reader.GetInt32("lakossag");
                    varoslistaz.Items.Add(nev + " - Lakosság: " +lakossag+" fő");
                }
            }
        }

        public void LatvanyossagokListazasa()
        {
            latvanyossagokLB.Items.Clear();
            var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT * FROM latvanyossagok ORDER BY nev";
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    int id = reader.GetInt32("id");
                    string nev = reader.GetString("nev");
                    string leiras = reader.GetString("leiras");
                    int ar = reader.GetInt32("ar");
                    latvanyossagokLB.Items.Add(nev + " - " + ar + " Ft");
                }
            }
        }
        

        private void felveszB_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(varosnevTB.Text)||lakosszamNM.Value==0)
            {
                MessageBox.Show("Minden mezőt ki kell tölteni. A lakosszám nem lehet nulla.");
                return;
            }
            var cmd = conn.CreateCommand();
            cmd.CommandText = @"INSERT INTO varosok
                               (nev,lakossag) 
                              VALUES(@nev,@lakossag)";
            cmd.Parameters.AddWithValue("@nev", varosnevTB.Text);
            cmd.Parameters.AddWithValue("@lakossag", lakosszamNM.Value);
            cmd.ExecuteNonQuery();

            VarosokListazasa();
        }

        private void latvanyosagfelveszB_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(latvnevTB.Text) || latvanyarNM.Value == 0 || string.IsNullOrWhiteSpace(latvanyleirTB.Text))
            {
                MessageBox.Show("Minden mezőt ki kell tölteni.");
                return;
            }
            int a = 4;
            var cmd = conn.CreateCommand();
            cmd.CommandText = @"INSERT INTO latvanyossagok
                               (nev,leiras,ar,varos_id) 
                              VALUES(@nev,@leiras,@ar,@varos_id)";
            cmd.Parameters.AddWithValue("@nev", latvnevTB.Text);
            cmd.Parameters.AddWithValue("@leiras", latvanyleirTB.Text);
            cmd.Parameters.AddWithValue("@ar", latvanyarNM.Value);
            cmd.Parameters.AddWithValue("@nev", latvnevTB.Text);
            cmd.Parameters.AddWithValue("@nev", a);
            cmd.ExecuteNonQuery();

            VarosokListazasa();
        }
    }
}
