﻿namespace LatvanyossagokApplication
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.varoslistaz = new System.Windows.Forms.ListBox();
            this.lakosszamNM = new System.Windows.Forms.NumericUpDown();
            this.varosnevTB = new System.Windows.Forms.TextBox();
            this.varosnevL = new System.Windows.Forms.Label();
            this.LakosszamL = new System.Windows.Forms.Label();
            this.felveszB = new System.Windows.Forms.Button();
            this.latvanyosagfelveszB = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.latvnevTB = new System.Windows.Forms.TextBox();
            this.latvanyossagokLB = new System.Windows.Forms.ListBox();
            this.szovegvarosLB = new System.Windows.Forms.Label();
            this.szoveglatvanyossagokLB = new System.Windows.Forms.Label();
            this.latvanyleirTB = new System.Windows.Forms.TextBox();
            this.latvanyarNM = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.lakosszamNM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.latvanyarNM)).BeginInit();
            this.SuspendLayout();
            // 
            // varoslistaz
            // 
            this.varoslistaz.FormattingEnabled = true;
            this.varoslistaz.Location = new System.Drawing.Point(12, 35);
            this.varoslistaz.Name = "varoslistaz";
            this.varoslistaz.Size = new System.Drawing.Size(285, 173);
            this.varoslistaz.TabIndex = 0;
            // 
            // lakosszamNM
            // 
            this.lakosszamNM.Location = new System.Drawing.Point(399, 68);
            this.lakosszamNM.Name = "lakosszamNM";
            this.lakosszamNM.Size = new System.Drawing.Size(120, 20);
            this.lakosszamNM.TabIndex = 1;
            // 
            // varosnevTB
            // 
            this.varosnevTB.Location = new System.Drawing.Point(399, 37);
            this.varosnevTB.Name = "varosnevTB";
            this.varosnevTB.Size = new System.Drawing.Size(120, 20);
            this.varosnevTB.TabIndex = 2;
            // 
            // varosnevL
            // 
            this.varosnevL.Location = new System.Drawing.Point(303, 37);
            this.varosnevL.Name = "varosnevL";
            this.varosnevL.Size = new System.Drawing.Size(90, 23);
            this.varosnevL.TabIndex = 3;
            this.varosnevL.Text = "Város neve:";
            // 
            // LakosszamL
            // 
            this.LakosszamL.Location = new System.Drawing.Point(303, 70);
            this.LakosszamL.Name = "LakosszamL";
            this.LakosszamL.Size = new System.Drawing.Size(90, 23);
            this.LakosszamL.TabIndex = 4;
            this.LakosszamL.Text = "Lakosok száma:";
            // 
            // felveszB
            // 
            this.felveszB.Location = new System.Drawing.Point(306, 96);
            this.felveszB.Name = "felveszB";
            this.felveszB.Size = new System.Drawing.Size(75, 23);
            this.felveszB.TabIndex = 5;
            this.felveszB.Text = "Felvétel";
            this.felveszB.UseVisualStyleBackColor = true;
            this.felveszB.Click += new System.EventHandler(this.felveszB_Click);
            // 
            // latvanyosagfelveszB
            // 
            this.latvanyosagfelveszB.Location = new System.Drawing.Point(303, 323);
            this.latvanyosagfelveszB.Name = "latvanyosagfelveszB";
            this.latvanyosagfelveszB.Size = new System.Drawing.Size(75, 23);
            this.latvanyosagfelveszB.TabIndex = 11;
            this.latvanyosagfelveszB.Text = "Felvétel";
            this.latvanyosagfelveszB.UseVisualStyleBackColor = true;
            this.latvanyosagfelveszB.Click += new System.EventHandler(this.latvanyosagfelveszB_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(303, 266);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 23);
            this.label1.TabIndex = 10;
            this.label1.Text = "Leírás:";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(303, 239);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 23);
            this.label2.TabIndex = 9;
            this.label2.Text = "Látványosság neve:";
            // 
            // latvnevTB
            // 
            this.latvnevTB.Location = new System.Drawing.Point(399, 239);
            this.latvnevTB.Name = "latvnevTB";
            this.latvnevTB.Size = new System.Drawing.Size(120, 20);
            this.latvnevTB.TabIndex = 8;
            // 
            // latvanyossagokLB
            // 
            this.latvanyossagokLB.FormattingEnabled = true;
            this.latvanyossagokLB.Location = new System.Drawing.Point(12, 237);
            this.latvanyossagokLB.Name = "latvanyossagokLB";
            this.latvanyossagokLB.Size = new System.Drawing.Size(285, 173);
            this.latvanyossagokLB.TabIndex = 6;
            // 
            // szovegvarosLB
            // 
            this.szovegvarosLB.Location = new System.Drawing.Point(9, 9);
            this.szovegvarosLB.Name = "szovegvarosLB";
            this.szovegvarosLB.Size = new System.Drawing.Size(100, 23);
            this.szovegvarosLB.TabIndex = 12;
            this.szovegvarosLB.Text = "Városok";
            // 
            // szoveglatvanyossagokLB
            // 
            this.szoveglatvanyossagokLB.Location = new System.Drawing.Point(9, 211);
            this.szoveglatvanyossagokLB.Name = "szoveglatvanyossagokLB";
            this.szoveglatvanyossagokLB.Size = new System.Drawing.Size(100, 23);
            this.szoveglatvanyossagokLB.TabIndex = 13;
            this.szoveglatvanyossagokLB.Text = "Látványosságok";
            // 
            // latvanyleirTB
            // 
            this.latvanyleirTB.Location = new System.Drawing.Point(399, 269);
            this.latvanyleirTB.Name = "latvanyleirTB";
            this.latvanyleirTB.Size = new System.Drawing.Size(120, 20);
            this.latvanyleirTB.TabIndex = 14;
            // 
            // latvanyarNM
            // 
            this.latvanyarNM.Location = new System.Drawing.Point(399, 295);
            this.latvanyarNM.Name = "latvanyarNM";
            this.latvanyarNM.Size = new System.Drawing.Size(120, 20);
            this.latvanyarNM.TabIndex = 15;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(303, 297);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 23);
            this.label3.TabIndex = 16;
            this.label3.Text = "Ár:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(769, 450);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.latvanyarNM);
            this.Controls.Add(this.latvanyleirTB);
            this.Controls.Add(this.szoveglatvanyossagokLB);
            this.Controls.Add(this.szovegvarosLB);
            this.Controls.Add(this.latvanyosagfelveszB);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.latvnevTB);
            this.Controls.Add(this.latvanyossagokLB);
            this.Controls.Add(this.felveszB);
            this.Controls.Add(this.LakosszamL);
            this.Controls.Add(this.varosnevL);
            this.Controls.Add(this.varosnevTB);
            this.Controls.Add(this.lakosszamNM);
            this.Controls.Add(this.varoslistaz);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.lakosszamNM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.latvanyarNM)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox varoslistaz;
        private System.Windows.Forms.NumericUpDown lakosszamNM;
        private System.Windows.Forms.TextBox varosnevTB;
        private System.Windows.Forms.Label varosnevL;
        private System.Windows.Forms.Label LakosszamL;
        private System.Windows.Forms.Button felveszB;
        private System.Windows.Forms.Button latvanyosagfelveszB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox latvnevTB;
        private System.Windows.Forms.ListBox latvanyossagokLB;
        private System.Windows.Forms.Label szovegvarosLB;
        private System.Windows.Forms.Label szoveglatvanyossagokLB;
        private System.Windows.Forms.TextBox latvanyleirTB;
        private System.Windows.Forms.NumericUpDown latvanyarNM;
        private System.Windows.Forms.Label label3;
    }
}

